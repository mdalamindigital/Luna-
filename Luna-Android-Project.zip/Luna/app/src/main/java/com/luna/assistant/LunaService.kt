package com.luna.assistant

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

class LunaService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private lateinit var face: LunaView
    private lateinit var lp: WindowManager.LayoutParams
    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private val hist = mutableListOf<Pair<String, String>>()
    private val sp get() = getSharedPreferences("luna", MODE_PRIVATE)
    private val isEn get() = sp.getBoolean("en", false)
    private val isWork get() = sp.getString("mode", "emotional") == "work"

    private val openWords = listOf("open", "kholo", "খোল", "খুল", "ওপেন", "চালু", "চালাও")
    private val searchWords = listOf("search", "সার্চ", "খুঁজ", "খুজ")
    private val researchWords = listOf("research", "রিসার্চ", "গবেষণা")
    private val alias = mapOf(
        "ইউটিউব" to "youtube", "ফেসবুক" to "facebook", "হোয়াটসঅ্যাপ" to "whatsapp", "গুগল" to "google",
        "ক্রোম" to "chrome", "মেসেঞ্জার" to "messenger", "ইনস্টাগ্রাম" to "instagram",
        "টেলিগ্রাম" to "telegram", "সেটিংস" to "settings", "ক্যামেরা" to "camera"
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("luna", "Luna", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "luna").setContentTitle("Luna chalu ache")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
        addBubble()
    }

    override fun onInit(s: Int) {}

    private fun addBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        face = LunaView(this)
        val size = (150 * resources.displayMetrics.density).toInt()
        lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 24; lp.y = 400
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false; var t0 = 0L
        face.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false; t0 = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (Math.abs(mx) > 12 || Math.abs(my) > 12) moved = true
                    if (moved) { lp.x = sx + mx; lp.y = sy + my; wm.updateViewLayout(face, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (System.currentTimeMillis() - t0 > 700) toggleMode() else listen()
                }
            }
            true
        }
        wm.addView(face, lp)
        face.set("happy")
    }

    private fun toggleMode() {
        val m = if (isWork) "emotional" else "work"
        sp.edit().putString("mode", m).apply()
        face.set("neutral")
        say(if (m == "work") t("Work mode chalu.", "Work mode on.") else t("Emotional mode chalu 💗", "Emotional mode on."))
    }

    private fun t(bn: String, en: String) = if (isEn) en else bn

    private fun say(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        tts?.run {
            val loc = if (isEn) Locale.US else Locale("bn", "BD")
            language = if (isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.getDefault()
            setPitch(1.25f)
            speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say(t("Ei phone-e voice recognition nai.", "No speech recognition here.")); return }
        tts?.stop(); rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    face.listening = false; face.set("neutral")
                    val s = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (s.isNullOrBlank()) say(t("Bujhte parlam na.", "Didn't catch that.")) else handle(s)
                }
                override fun onError(e: Int) { face.listening = false; face.set("sad"); say(t("Shunte parlam na, abar bolo.", "Couldn't hear, try again.")) }
                override fun onReadyForSpeech(p: Bundle?) { face.listening = true; face.invalidate() }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isEn) "en-US" else "bn-BD")
            })
        }
    }

    private fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }

    private fun findApp(lower: String): Intent? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (r in packageManager.queryIntentActivities(i, 0)) {
            val n = r.loadLabel(packageManager).toString().lowercase()
            if (n.length >= 3 && lower.contains(n)) return packageManager.getLaunchIntentForPackage(r.activityInfo.packageName)
        }
        return null
    }

    private fun handle(text: String) {
        var low = text.lowercase().replace(" dot ", ".")
        for ((k, v) in alias) low = low.replace(k, v)
        val wantsOpen = openWords.any { low.contains(it) }
        when {
            researchWords.any { low.contains(it) } -> ai(text, true)
            searchWords.any { low.contains(it) } -> {
                var q = low
                for (w in searchWords + listOf("google", "গুগল", "e", "-e", "এ")) if (w.length > 2) q = q.replace(w, " ")
                q = q.trim()
                face.set("happy"); say(t("Google-e khujchi.", "Searching Google."))
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))))
            }
            wantsOpen -> {
                val url = Regex("([a-z0-9-]+\\.(com|org|net|edu|io|bd|gov|info)[^\\s]*)").find(low)?.value
                val app = findApp(low)
                if (url != null) { face.set("happy"); say(t("Kholchi.", "Opening.")); launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://$url"))) }
                else if (app != null) { face.set("happy"); say(t("Thik ache, kholchi.", "Okay, opening.")); launch(app) }
                else ai(text, false)
            }
            else -> ai(text, false)
        }
    }

    private fun sys(research: Boolean): String {
        val lang = if (isEn) "English" else "Bangla script (বাংলা অক্ষরে)"
        var s = "You are Luna, an animated voice assistant character on the user's (Rahman's) phone. Reply in $lang, short (1-3 sentences) because it is spoken aloud. "
        s += if (isWork) "Mode WORK: no emotion, serious, concise, accurate. Mood must be neutral. "
        else "Mode EMOTIONAL: caring, sweet, playful like a girlfriend; can tease, get angry if he is rude or ignores you, cry if sad, get shy. Never guilt-trip, never be jealous or controlling, never discourage him from friends, family, sleep or study. If he seems truly distressed, be calm and encourage talking to someone real. "
        if (research) s += "Research the topic with web search, then give a short spoken summary of the key findings. "
        s += "Your final answer must be ONLY this JSON: {\"mood\":\"neutral|happy|angry|sad|shy\",\"text\":\"...\"}"
        return s
    }

    private fun ai(q: String, research: Boolean) {
        val key = sp.getString("key", "") ?: ""
        if (key.isBlank()) { say(t("App-e Claude API key dao.", "Please add your API key in the app.")); return }
        face.set("neutral"); Toast.makeText(this, "…", Toast.LENGTH_SHORT).show()
        thread {
            val out = try { call(key, q, research) } catch (e: Exception) { Pair("sad", t("Internet ba key-te shomoshya.", "Network or key problem.")) }
            h.post {
                if (out.first != "sad" || out.second.length > 0) { hist.add("user" to q); hist.add("assistant" to out.second) }
                face.set(if (isWork) "neutral" else out.first); say(out.second)
            }
        }
    }

    private fun call(key: String, q: String, research: Boolean): Pair<String, String> {
        val msgs = JSONArray()
        for ((r, c) in hist.takeLast(8)) msgs.put(JSONObject().put("role", r).put("content", c))
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 1000).put("system", sys(research)).put("messages", msgs)
        if (research) body.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 90000; c.doOutput = true
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val raw = (if (c.responseCode >= 400) c.errorStream else c.inputStream).bufferedReader().readText()
        val root = JSONObject(raw)
        if (root.has("error")) return Pair("sad", t("API error: ", "API error: ") + root.getJSONObject("error").optString("message"))
        val arr = root.getJSONArray("content"); val sb = StringBuilder()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("type") == "text") sb.append(o.getString("text")) }
        val txt = sb.toString(); val a = txt.lastIndexOf("{\"mood\""); val b = txt.lastIndexOf('}')
        return try { val j = JSONObject(txt.substring(a, b + 1)); Pair(j.optString("mood", "neutral"), j.getString("text")) }
        catch (e: Exception) { Pair("neutral", txt.trim()) }
    }

    override fun onDestroy() {
        try { wm.removeView(face) } catch (e: Exception) {}
        rec?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
