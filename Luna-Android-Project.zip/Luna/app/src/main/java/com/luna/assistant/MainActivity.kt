package com.luna.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var key: EditText
    private lateinit var en: Switch
    private lateinit var work: Switch

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("luna", MODE_PRIVATE)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply { text = "Luna 💗"; textSize = 28f })
        key = EditText(this).apply { hint = "Claude API key (sk-ant-...)"; setText(sp.getString("key", "")); setSingleLine() }
        l.addView(key)
        en = Switch(this).apply { text = "English-e kotha bolbo (off = Bangla)"; isChecked = sp.getBoolean("en", false) }
        l.addView(en)
        work = Switch(this).apply { text = "Work mode (emotion off)"; isChecked = sp.getString("mode", "emotional") == "work" }
        l.addView(work)
        fun btn(t: String, f: () -> Unit) { l.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        btn("1. Overlay permission dao") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Luna chalu koro") { save(); start() }
        btn("Luna bondho koro") { stopService(Intent(this, LunaService::class.java)) }
        setContentView(l)
    }

    private fun save() {
        getSharedPreferences("luna", MODE_PRIVATE).edit()
            .putString("key", key.text.toString().trim())
            .putBoolean("en", en.isChecked)
            .putString("mode", if (work.isChecked) "work" else "emotional").apply()
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Age 1 number button-e overlay permission dao", Toast.LENGTH_LONG).show(); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) go() else requestPermissions(miss.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go()
        else Toast.makeText(this, "Mic permission lagbe", Toast.LENGTH_LONG).show()
    }

    private fun go() {
        startForegroundService(Intent(this, LunaService::class.java))
        Toast.makeText(this, "Luna screen-e ashbe. Home-e jao.", Toast.LENGTH_LONG).show()
    }
}
