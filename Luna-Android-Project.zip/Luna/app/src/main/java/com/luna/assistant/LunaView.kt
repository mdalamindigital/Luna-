package com.luna.assistant

import android.content.Context
import android.graphics.*
import android.view.View

class LunaView(c: Context) : View(c) {
    var mood = "happy"
    var listening = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hair = 0xFF3B2750.toInt()
    private val ink = 0xFF2A1F2D.toInt()
    private val lip = 0xFFB5475E.toInt()

    fun set(m: String) { mood = m; invalidate() }

    private fun stroke(w: Float, col: Int) { p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND; p.color = col }
    private fun fill(col: Int) { p.style = Paint.Style.FILL; p.color = col }

    override fun onDraw(cv: Canvas) {
        cv.save(); val s = width / 200f; cv.scale(s, s)
        if (listening) { stroke(5f, 0xFFE8528A.toInt()); cv.drawCircle(100f, 100f, 97f, p) }
        fill(hair); cv.drawCircle(100f, 100f, 92f, p)
        fill(if (mood == "angry") 0xFFF7B8A8.toInt() else 0xFFFBDCC8.toInt()); cv.drawCircle(100f, 108f, 76f, p)
        fill(hair); cv.drawArc(RectF(24f, 24f, 176f, 150f), 180f, 180f, true, p)
        if (mood == "happy" || mood == "shy") {
            fill(0xFFFF7A9C.toInt()); p.alpha = if (mood == "shy") 190 else 110
            cv.drawCircle(58f, 134f, 11f, p); cv.drawCircle(142f, 134f, 11f, p); p.alpha = 255
        }
        for (x in floatArrayOf(70f, 130f)) {
            if (mood == "happy") { stroke(4f, ink); cv.drawArc(RectF(x - 12, 104f, x + 12, 130f), 200f, 140f, false, p) }
            else {
                fill(ink); cv.drawOval(RectF(x - 11, 98f, x + 11, 126f), p)
                fill(Color.WHITE); cv.drawCircle(x - 3 + (if (mood == "shy") 4 else 0), 107f, 4f, p)
            }
        }
        if (mood == "angry") { stroke(5f, hair); cv.drawLine(52f, 90f, 86f, 102f, p); cv.drawLine(148f, 90f, 114f, 102f, p) }
        if (mood == "sad") {
            stroke(4f, hair); cv.drawLine(54f, 96f, 84f, 88f, p); cv.drawLine(146f, 96f, 116f, 88f, p)
            fill(0xFF6CC4FF.toInt()); cv.drawOval(RectF(64f, 130f, 74f, 150f), p); cv.drawOval(RectF(126f, 130f, 136f, 150f), p)
        }
        when (mood) {
            "happy" -> { fill(lip); cv.drawArc(RectF(82f, 134f, 118f, 162f), 0f, 180f, true, p) }
            "angry", "sad" -> { stroke(3.5f, lip); cv.drawArc(RectF(86f, 150f, 114f, 170f), 200f, 140f, false, p) }
            "shy" -> { stroke(3f, lip); cv.drawArc(RectF(90f, 140f, 110f, 154f), 20f, 140f, false, p) }
            else -> { stroke(3f, lip); cv.drawArc(RectF(88f, 138f, 112f, 156f), 20f, 140f, false, p) }
        }
        cv.restore()
    }
}
